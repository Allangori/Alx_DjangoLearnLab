from django.apps import AppConfig


class ParcelAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'parcel_app'
